angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        $rootScope.searchBox = true;
        if (!sessionStorage.getItem("loginId")) {
            $location.path("/login");
        }
        $scope.breadCrumbs = [{
            name: 'Home',
            state: 'login'
        }, {
            name: 'Product Catalogue',
            state: 'productCatalogue'
        }, {
            name: 'Product Details',
            state: 'productDetails'
        }];
        persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
            $scope.data = data;
            bindDataToView()
        }, function (data) {
            console.error("Unabel to Fetch items Details")
        });
        function bindDataToView() {
            $scope.name = $scope.data.name;
            $scope.description = $scope.data.description;
            $scope.images = $scope.data.images;
            $scope.additionalFeatures = $scope.data.additionalFeatures;
            $scope.android = $scope.data.android;
            $scope.availability = $scope.data.availability;
            $scope.battery = $scope.data.battery;
            $scope.camera = $scope.data.camera;
            $scope.connectivity = $scope.data.connectivity;
            $scope.display = $scope.data.display;
            $scope.hardware = $scope.data.hardware;
            $scope.id = $scope.data.id;
            $scope.sizeAndWeight = $scope.data.sizeAndWeight;
            $scope.storage = $scope.data.storage;
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        }

        $scope.addToCart = function () {
            //persistentOLXFactory.cartContent.push(persistentOLXFactory.selectedItem);
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                var obj = {};
                obj.name = data.name;
                obj.price = data.price;
                persistentOLXFactory.cartContent.push(angular.copy(obj));
                $state.go('cart');
            }, function (data) {
                console.error("Failed to Fetch Item Details" + data);
            });

        };
        $scope.$on('onItemClickInSearchBox', function () {
            persistentOLXFactory.fetchSearchItemDetails().then(function (data) {
                $scope.data = data;
                bindDataToView()
            }, function (data) {
                console.error("Unabel to Fetch items Details")
            });
        })
    });