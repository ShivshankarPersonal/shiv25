(function () {
    angular.module("persistentOLXApp")
        .controller("loginController", function ($scope, $state, persistentOLXFactory, $rootScope, $location, $timeout) {
            $rootScope.pageName = 'Login';
            $rootScope.searchBox = false;
            $scope.onLoginBtnClick = function () {
                $rootScope.searchBox = true;
            };

            $scope.showPuzzleArea = false;
            $scope.passwordFieldError = false;
            $scope.onPasswordFieldFocus = function () {
                $scope.passwordFieldError = true;
            };
            $scope.loginDisable = true;
            $scope.showCompleteError = false;
            $scope.imageNumber = 0;
            $scope.puzzleSuccess = false;

            $scope.onUserNameEnter = function ($event) {
                persistentOLXFactory.getUserDetails().then(function (data, status, headers, config) {
                    $scope.userDetailsList = data.users;
                    $scope.capPuzzleList = data.capPuzzle;
                }, function (data, status, headers, config) {
                    console.error("error", data);
                });
            };
            $scope.onPasswordEnter = function () {
                if ($scope.password && $scope.userName) {
                    $scope.loginDisable = false;
                }
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            };
            $scope.wrongLoginAttempts = 0;
            $scope.loginSuccess = false;
            $scope.onLoginClick = function () {
                for (var i = 0; i < $scope.userDetailsList.length; i++) {
                    if ($scope.userName) {
                        if (($scope.userName.toLowerCase() === $scope.userDetailsList[i].username.toLowerCase() || $scope.userName.toLowerCase() === $scope.userDetailsList[i].emalID.toLowerCase()) && ($scope.password === $scope.userDetailsList[i].password )) {
                            if($scope.showPuzzleArea){
                                if($scope.puzzleSuccess){
                                    sessionStorage.setItem('loginId', $scope.userName);
                                    $scope.showCompleteError = false;
                                    $scope.loginSuccess = true;
                                    $rootScope.searchBox = true;
                                    $state.go('productCatalogue')
                                }
                            }else {
                                sessionStorage.setItem('loginId', $scope.userName);
                                $scope.showCompleteError = false;
                                $scope.loginSuccess = true;
                                $rootScope.searchBox = true;
                                $state.go('productCatalogue')
                            }
                        }
                    }
                }
                if (!$scope.loginSuccess) {
                    $scope.showCompleteError = true;
                    $scope.wrongLoginAttempts++;
                    if ($scope.wrongLoginAttempts > 3) {
                        $scope.showPuzzleArea = true;
                        $scope.imageNumber = 0;
                        $scope.showNextImage();
                        $scope.userFieldError = false;
                        $timeout(function () {
                            $scope.$emit("showCaptchaImagePuzzle", {});
                        }, 100);
                        $scope.$emit("startCountDown", {});
                        return;
                    }
                }
            };

            $scope.showNextImage = function () {
                var capPuzzleDetails = $scope.capPuzzleList;
                if ($scope.capPuzzleList.length > $scope.imageNumber) {
                    $scope.img = $scope.capPuzzleList[$scope.imageNumber].image + '?' + new Date().getTime();
                } else {
                    $scope.imageNumber = 0;
                    $scope.img = $scope.capPuzzleList[$scope.imageNumber].image + '?' + new Date().getTime();
                }
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
            };

            $scope.$on("timeUp", function () {
                $scope.imageNumber += 1;
                $scope.showNextImage();

                $timeout(function () {
                    $scope.$emit("reloadNextImage", {});
                    $scope.$emit("startCountDown", {});
                }, 100);
            });
            $scope.$on("successfullySolvedPuzzle", function () {
                $scope.puzzleSuccess = true;
                if ($scope.password && $scope.userName) {
                    $scope.loginDisable = false;
                }
                if (!$scope.$$phase) {
                    $scope.$apply();
                }
                return;
            });
        });
})();
