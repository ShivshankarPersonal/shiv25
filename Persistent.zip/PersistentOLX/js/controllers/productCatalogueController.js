angular.module("persistentOLXApp")
    .controller("productCatalogueController", function ($scope, $state, persistentOLXFactory, $rootScope, $location) {
        $rootScope.searchBox = true;
         if (!sessionStorage.getItem("loginId")) {
             $location.path("/login");
         }
        $scope.breadCrumbs = [{
            name:'Home',
            state:'login'
        }, {
            name:'Product Catalogue',
            state:'productCatalogue'
        }];
        $scope.max = 5;
        $scope.userRating = 1;
        $scope.itemsPerPage = 7;
        $scope.currentPage = 1;
        $scope.stars = [1, 2, 3, 4, 5];
        $scope.brands = [];
        $scope.brandFilterChipShow = false;
        $scope.priceRangeFilterChipShow = false;
        $scope.userRatingsFilterChipShow = false;
        $scope.pageChanged = function () {
            var endIndex = ($scope.currentPage - 1) * 7;
            $scope.filteredItemss = $scope.items.slice(endIndex, endIndex + 7)
        };
        $scope.onListItemClick = function (itemID) {
            persistentOLXFactory.selectedItem = itemID;
            $state.go('productDetails')
        };
        $scope.renderResult = function () {
            var tempArray = angular.copy($scope.data);
            $scope.items = tempArray.filter(function (element) {
                var brand = '';
                if($scope.brand === undefined || $scope.brand === null ){
                    brand = element.brand;
                }else{
                    brand = $scope.brand;
                }
                return brand === element.brand && element.price >= $scope.itemRange && element.ratings >= parseInt($scope.userRating);
            });
            $scope.filteredItemss  = $scope.items;
            $scope.totalItems = $scope.items.length;
        };
        $scope.onBrandChange = function () {
            $scope.renderResult();
            $scope.brandFilterChipShow = true;
        };
        $scope.onPriceRangeChange = function () {
            $scope.renderResult();
            $scope.priceRangeFilterChipShow = true;
        };
        $scope.onRatingChanges = function () {
            $scope.renderResult();
            $scope.userRatingsFilterChipShow = true;
        };
        $scope.removeBrandFilter = function () {
            $scope.brand = null;
            $scope.brandFilterChipShow = false;
            $scope.renderResult();
            if (!$scope.$$phase) {
                $scope.$apply();
            }
        };
        $scope.removePriceRangeFilter = function () {
            $scope.itemRange = $scope.minRange;
            $scope.priceRangeFilterChipShow = false;
            $scope.renderResult();

        };
        $scope.removeUserRatingFilter = function () {
            $scope.userRating = 1;
            $scope.userRatingsFilterChipShow = false;
            $scope.renderResult();
        };

        $scope.removeDuplicate = function (arr) {
            var exists = {},
                outArr = [],
                elm;
            for (var i = 0; i < arr.length; i++) {
                elm = arr[i];
                if (!exists[elm]) {
                    outArr.push(elm);
                    exists[elm] = true;
                }
            }
            return outArr;
        };
        persistentOLXFactory.fetchPhonesList('phones').then(function (data) {
            $scope.data = data;
            $scope.items = data;
            $scope.filteredItemss = data;
            $scope.totalItems = $scope.items.length;
            var tempBrandsArray = [];
            var tempPriceArray = [];
            for (var i = 0; i < data.length; i++) {
                tempBrandsArray.push(data[i].brand);
                tempPriceArray.push(data[i].price);
            }
            $scope.brands = $scope.removeDuplicate(tempBrandsArray);
            $scope.minRange = Math.min.apply(null, tempPriceArray);
            $scope.maxRange = Math.max.apply(null, tempPriceArray);
            $scope.itemRange = $scope.minRange;
        }, function (data) {
            console.error("Unable to Fetch Product Catalogue list")
        });
    });